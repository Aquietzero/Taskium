$(function() {

  // var ps = new ParticleSystem();
  // var position = new Vector2(10, 200);
  // var velocity = new Vector2(50, -50);
  // var acceleration = new Vector2(0, 10);
  // var dt = 0.01;
  var canvas = document.getElementById('particleSystem');
  var ctx = canvas.getContext('2d');
  var firework = new ParticleSystemEnvironment();

  firework.init({
    ctx: ctx, 
    fps: 0.01,
    particle: {
      life: 1, 
      wave: Math.PI/18,
      /*
      position: {
        type: Const.RANDOM,
        x_min: 0,
        x_max: 950,
        y_min: 0, 
        y_max: 550
      },
      */
      position: {
        type: Const.FIXED,
        value: new Vector2(525, 350)
      },
      velocity: {
        type: Const.RANDOM,
        value: 130,
        direction: Math.PI,
        scatter: Math.PI/10,
        fluctuation: 30
      },
      colorFunc: {
        stops: [0, 0.5, 0.7, 1],
        colors: [Color.RED, Color.MAGENTA, Color.BLUE, new Color(0, 0, 0, 0)]
      },
      sizeFunc: {
        stops: [0, 1],
        sizes: [1, 1]
      }
    },
    motion_blur: true,
    generation_num: 1,
    type: Const.RANDOM
  });

  /*
  firework.particle_system.addField(new Field({
    position: new Vector2(400, 200),
    color: Color.BLUE,
    size: 5
  }));

  firework.particle_system.addField(new Field({
    position: new Vector2(550, 250),
    color: Color.GREEN,
    size: 5,
    type: Const.REBEL
  }));
  */

  // Start and stop the particle system
  $('#start').bind('click', function() {
    firework.run();
  });
  $('#stop').bind('click', function() {
    firework.stop();
  });

  // Draggable field support
  $('#particleSystem').mousedown(function(e) {
    firework.setFieldMovable(e);
  });
  $('#particleSystem').mousemove(function(e) {
    firework.moveField(e);
  });
  $('#particleSystem').mouseup(function() {
    firework.setFieldUnmovable();
  });

  // Add rebel or attract field
  $('#addRebelField').bind('click', function() {
    firework.particle_system.addField(new Field({
      position: new Vector2(475, 250),
      color: Color.GREEN,
      size: 5,
      type: Const.REBEL,
      strength: 40000
    }));
  });
  
  $('#addAttractField').bind('click', function() {
    firework.particle_system.addField(new Field({
      position: new Vector2(475, 250),
      color: Color.BLUE,
      size: 5,
      type: Const.ATTRACT,
      strength: 40000
    }));
  });

});


