# Particle System 

The ideas below are listed under brain storm...


## Intention

Provide an easy-to-use and understandable interface for dummies who wants to make fun effects or create simple web games but don't want to get down to those complex physics.


## Main principle that should definitely be followed.

* The implementation of the algorithm and rendering should be separated.
* Both the rendering configuration and algorithm configuration can be changed in runtime.
* The particle system should be work fined both in canvas and webGL. (Actually, the algorithm is ok because it has nothing to do with the rendering stuff).
* If the user-passed configuration misses something important, then use default instead.


## System components.

* There are several parts of the system:
    + Particle
    + Particle System
    + Particle System Controller
    + Particle Renderer

Try to keep those rendering processes out of particle and particle system. Consider to use particle system controller to connect the basic particle and the rendering.


### Particle

Particle only concerns the physical characteristic of a particle. But consider to bound a render method to a particle so that user can change the rendering method at runtime. One important issue is how to initialize a particle. Since there are so many attributes that affects the particles.
