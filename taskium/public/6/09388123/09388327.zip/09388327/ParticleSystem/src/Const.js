var Const = {

  // Messages.
  SUCCESS : 'Success',
  DEFAULT : 'Default',
  ATTRACT : 'Attract',
  REBEL   : 'Rebel',
  RANDOM  : 'Random',
  FIXED   : 'Fixed',

}

if (typeof module != 'undefined')
  module.exports = Const;
