/* 
 * complex.js defines a psudoclass which makes it convenient to manipulate
 * complex numbers.
 */

function Complex(real, imag) {
  this.x = typeof real == 'number' ? real : 0;
  this.y = typeof imag == 'number' ? imag : 0;
}


// Returns the magnitude of the complex, which is the square root of the
// square some of real part and imagine part of the complex.
Complex.prototype.magnitude = function() {
  return Math.sqrt(this.x * this.x + this.y + this.y);
}

// The negative of the complex number.
Complex.prototype.negative = function() {
  return new Complex(-this.x, -this.y);
}


// Scale the complex number with a number.
Complex.prototype.scale = function(factor) {
  if (typeof factor == 'number')
    return new Complex(factor * this.x, factor * this.y);
  else
    throw new Error('factor should be a number');
}


// The four basic arithmetic operations of complex number.
Complex.prototype.add = function(that) {
  return new Complex(this.x + that.x, this.y + that.y);
}

Complex.prototype.sub = function(that) {
  return this.add(that.negative);
}

Complex.prototype.mul = function(that) {
  return new Complex(this.x * that.x - this.y * that.y,
                     this.x * that.y + this.y * that.x);
}

Complex.prototype.div = function(that) {

}


// Converts the complex number to a string.
Complex.prototype.toString = function() {
  return '(' + this.x + ', ' + this.y + ')';
}


// Converts the complex number to a single value.
Complex.prototype.toValue = function() {
  return this.x;
}


// Compares two complex numbers. If that is a complex number, that the two
// numbers are comparable. The return value determines that relationship.
// If two numbers are not comparable, then the result will be false.
Complex.prototype.equals = function(that) {
  if (that.hasOwnProperty('x') && that.hasOwnProperty('y')) {
    if (typeof that.x == 'number' &&
        typeof that.y == 'number') {
      var result = this.x - that.x;
      if (result == 0)
        return this.y - that.y;
      return result;
    }
  }
  return false;
}

Complex.prototype.compareTo = Complex.prototype.equals;

// Class methods.
Complex.add = function(c1, c2) {
  return new Complex(c1.x + c2.x, c1.y + c2.y);
}


var a = new Complex(1, 2);
var b = new Complex(1, 1);

console.log(a == b);
console.log(a.equals(b) >= 0);

console.log("a -> " + a);
console.log("b -> " + b);

