// A basic implementation of a particle system.

// var Vector2 = require('./Vector2');

function ParticleSystem() {

  // Private attributes
  this._particles = new Array();
  this._particles_num = Number.POSITIVE_INFINITY;
  this._fields = new Array();

}

ParticleSystem.Gravity = new Vector2(0, 980);
ParticleSystem.prototype = {

  // Aging the particles in the particle system. If the particle dies,
  // removes it from the particle array. Otherwise, increases its age.
  _aging: function(dt) {
    for (var i = 0; i < this._particles.length; ) {
      this._particles[i].age += dt;
      var p = this._particles[i];
      if (p.age > p.life)
        this._kill(i)
      else
        i++;
    }
  },

  // Kills the particle with the given index.
  _kill: function(index) {
    if (this._particles.length > 1)
      this._particles[index] = this._particles[this._particles.length - 1];
    this._particles.pop();
  },

  // Apply the gravity as the basic acceleration of the particles.
  _applyGravity: function() {
    this._particles.map(function(p) {
      p.acceleration = ParticleSystem.Gravity;
    });
  },

  _applyFields: function() {
    for (var i = 0; i < this._fields.length; ++i) {
      var field = this._fields[i];
      var force, distance;
      this._particles.map(function(p) {
        distance = field.position.sub(p.position).squareLength();
        if (field.type == Const.ATTRACT)
          force = field.position.sub(p.position).scale(field.strength / distance);
        else
          force = p.position.sub(field.position).scale(field.strength / distance);
        p.acceleration = p.acceleration.add(force);
      });
    }
  },

  _applyEffectors: function() {
    this._particles.map(function(p) {
      p.effector();
    });
  },

  // Kinematic movements.
  _kinematics: function(dt) {
    this._particles.map(function(p) {
      p.move(dt);
      p.accelerate(dt);
    });
  },

  _renderParticles: function(ctx) {
    this._particles.map(function(p) {
      p.render(ctx);      
    });
  },

  _renderFields: function(ctx) {
    this._fields.map(function(f) {
      f.render(ctx);
    });
  },

  // Support draggable fields.
  _setFieldMovable: function(e) {
    this._fields.map(function(f) {
      f.setFieldMovable(e);
    });
  },

  _moveField: function(e) {
    this._fields.map(function(f) {
      if (f.movable)
        f.move(e);
    });
  },

  _setFieldUnmovable: function() {
    this._fields.map(function(f) {
      f.movable = false;
    });
  },

  // Public methods.
  emit: function(particle) {
    if (this._particles.length < this._particles_num) {
      this._particles.push(particle);
    }
  },

  addField: function(field) {
    this._fields.push(field);
  },

  render: function(ctx) {
    this._renderFields(ctx);
    this._renderParticles(ctx);
  },

  // For extending the basci particle system.
  extendSystem: function(obj) {
    for (key in obj) {
      this[key] = obj[key];
    }
  }

}
