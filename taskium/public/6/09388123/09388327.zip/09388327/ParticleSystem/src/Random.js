// Random.js defines some random number generators.

var Random = {

  // Borrows the random method in the Math module to generate numbers
  // between 0 and 1.
  random : Math.random,

  // Randomly generates a two dimensional vector whose components'
  // length are restricted in range 0 to 1.
  randomVector2: function(angle, scatter) {
    var angle = angle !== undefined ? angle : 0;
    var scatter = scatter !== undefined ? scatter : 2*Math.PI;

    var theta = angle - scatter + 2 * Math.random() * scatter;
    return new Vector2(Math.sin(theta), Math.cos(theta));
  },

  // Randomly generates a number between from and to.
  randomRange: function(from, to) {
    return from + Math.random() * (to - from);
  },

  // Randomly generates a vector whose components are right in the
  // given two ranges.
  randomRangedVector2: function(from1, to1, from2, to2) {
    return new Vector2(
      this.randomRange(from1, to1),
      this.randomRange(from2, to2)
    );
  }

};

