// Particle.js defines the basic model of a particle.

// var Vector2 = require('./Vector2');

function Particle(configs) {

  this.life  = configs.life  !== undefined ? configs.life  : Infinity;
  this.color = configs.color !== undefined ? configs.color : new Color(0, 0, 0, 0);
  this.size  = configs.size  !== undefined ? configs.size  : 1;
  this.wave  = configs.wave  !== undefined ? configs.wave  : 0;

  this.acceleration = Vector2.ZERO;
  this.age = 0;

  // Configurative attributes
  this.setPosition(configs.position);
  this.setVelocity(configs.velocity);

  // Functional control attributes
  this.setSizeFunc(configs.sizeFunc);
  this.setColorFunc(configs.colorFunc);

  this.velocityFunc = function(v) { return v; }
  
}

Particle.DEFAULT_VELOCITY = new Vector2(100, 100);
Particle.DEFAULT_POSITION = new Vector2(0, 0);

Particle.prototype = {
  
  accelerate: function(dt) {
    this.velocity = this.velocity.add(this.acceleration.scale(dt));
  },

  move: function(dt) {
    this.position = this.position.add(this.velocity.scale(dt));
  },

  effector: function() {
    this.velocity = this.velocity.rotate(Random.randomRange(-this.wave, this.wave));
  },

  // setPosition receives a position configuration. If the type of position is fixed,
  // then the emiting position of the particle would be the given position. Otherwise,
  // the emitting position will be randomly selected in the rectangle given by x_min,
  // x_max, y_min and y_max.
  setPosition: function(p) {
    if (p !== undefined) {
      if (p.type !== undefined) {
        switch (p.type) {
          // Random particle emitting position.
          case Const.RANDOM:
            var x_min = p.x_min !== undefined ? p.x_min : 0;
            var x_max = p.x_max !== undefined ? p.x_max : 1;
            var y_min = p.y_min !== undefined ? p.y_min : 0;
            var y_max = p.y_max !== undefined ? p.y_max : 1;

            this.position = Random.randomRangedVector2(x_min, x_max, y_min, y_max);
            break;
          // Fixed particle emitting position.
          case Const.FIXED:
            if (p.value !== undefined)
              this.position = p.value;
            else
              this.position = DEFAULT_POSITION;
            break;
        }
      }
      else
        this.position = Particle.DEFAULT_POSITION; 
    }
    else
      this.position = Particle.DEFAULT_POSITION; 
  },

  // setVelocity receives the velocity configuration. If the velocity type is fixed, then
  // the velocity will be set to a fixed given value. Otherwise, the velocity is randomly
  // set according to the value and the fluctuation of the velocity.
  setVelocity: function(v) {
    if (v !== undefined) {
      var value       = v.value       !== undefined ? v.value : 600;
      var fluctuation = v.fluctuation !== undefined ? v.fluctuation : 100;
      var direction   = v.direction   !== undefined ? v.direction : 0;
      var scatter     = v.scatter     !== undefined ? v.scatter : Math.PI;

      if (v.type !== undefined) {
        switch (v.type) {
          // Random velocity has a random emit angle and a random emit velocity.
          // The random emit angle is any angle between 0 to 360 degrees.
          // The ranodm emit velocity takes the value as the mean and takes the fluctuation
          // as the derivation.
          case Const.RANDOM:
            this.velocity = Random.randomVector2(direction, scatter)
                                  .scale(Random.randomRange(value - fluctuation, value + fluctuation));
            break;
        }
      } 
      else
        this.velocity = Particle.DEFAULT_VELOCITY;
    }
    else
      this.velocity = Particle.DEFAULT_VELOCITY;
  },

  setColorFunc: function(c) {
    var stops  = c.stops !== undefined ? c.stops : [0, 0.5, 1]; 
    var colors = c.colors !== undefined ? c.colors : [Color.YELLOW, Color.RED, Color.BLACK];

    this.colorFunc = (function(stops, colors) {
      return function() {
        var rate = this.age / this.life;
        for (var i = 0; i < stops.length - 1; ++i) {
          if (rate >= stops[i] && rate <= stops[i + 1]) {
            this.color.setBetween(colors[i], 
                                  colors[i + 1], 
                                  (rate - stops[i]) / (stops[i + 1] - stops[i]));
          }
        }
      };
    })(stops, colors);
  },

  setSizeFunc: function(s) {
    var stops = s.stops !== undefined ? s.stops : [0, 1]; 
    var sizes = s.sizes !== undefined ? s.sizes : [1, 1];

    this.sizeFunc = (function(stops, sizes) {
      return function() {
        var rate = this.age / this.life;
        for (var i = 0; i < stops.length - 1; ++i) {
          if (rate >= stops[i] && rate <= stops[i + 1]) {
            var beginSize = sizes[i];
            var endSize   = sizes[i + 1];
            this.size = beginSize + (endSize - beginSize) * (rate - stops[i]) / (stops[i + 1] - stops[i]);
          }
        }
      };
    })(stops, sizes);
  },

  render : function(ctx) {
    // this.color.a = 1 - this.age / this.life;
    this.colorFunc();
    this.sizeFunc();

    ctx.fillStyle = this.color.toString();
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, this.size, 0, Math.PI*2, true);
    ctx.closePath();
    ctx.fill();
  }

}


// A Particle making factory.
function ParticleFactory(configs) {}

ParticleFactory.prototype = function() {
  var _particle_class = BasicParticle;

  return {
    // Sets the particle class.
    setParticleClass: function(particleClass) {
      _particle_class = particleClass;
    },

    // A factory function self makes particles with the given configurations.
    makeParticle: function(configs) {
      return new _particle_class(configs);
    }
  }
}

