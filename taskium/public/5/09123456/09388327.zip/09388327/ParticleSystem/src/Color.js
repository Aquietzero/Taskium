// Color.js defines a simple color class.

function Color(r, g, b, a) {
  this.r = r || 0;
  this.g = g || 0;
  this.b = b || 0;
  this.a = a || 1;
}

Color.prototype = {

  // Set the current color to a specific color between the begin
  // color and the end color with a given rate.
  setBetween: function(beginColor, endColor, rate) {
    this.r = beginColor.r + (endColor.r - beginColor.r) * rate;
    this.g = beginColor.g + (endColor.g - beginColor.g) * rate;
    this.b = beginColor.b + (endColor.b - beginColor.b) * rate;
    this.a = beginColor.a + (endColor.a - beginColor.a) * rate;

    this.r = this.r > 1 ? 1 : this.r;
    this.g = this.g > 1 ? 1 : this.g;
    this.b = this.b > 1 ? 1 : this.b;

    this.r = this.r < 0 ? 0 : this.r;
    this.g = this.g < 0 ? 0 : this.g;
    this.b = this.b < 0 ? 0 : this.b;
  }, 

  // Convert color to different channels.
  toString: function() {
    return "rgba("
      + Math.floor(this.r * 255) + ','
      + Math.floor(this.g * 255) + ','
      + Math.floor(this.b * 255) + ','
      + this.a.toFixed(2) + ")";
  },

}

Color.RED     = new Color(1, 0, 0);
Color.GREEN   = new Color(0, 1, 0);
Color.BLUE    = new Color(0, 0, 1);
Color.YELLOW  = new Color(1, 1, 0);
Color.CYAN    = new Color(0, 1, 1);
Color.MAGENTA = new Color(1, 0, 1);
Color.WHITE   = new Color(1, 1, 1);
Color.BLACK   = new Color(0, 0, 0);


// Color in HSI color model.
function ColorHSI(color) {

  // Convert color to HSI model from RGB model.
  var R = color.r,
      G = color.g,
      B = color.b;

  var r = R / (R + B + G),
      g = G / (R + B + G),
      b = B / (R + B + G);

  var H = Math.acos(
    ((r - g) + (r - b)) /
    2*Math.sqrt((r - g)*(r - g) + (r - b)*(g - b))
  );
  var S = 1 - 3*Math.min(r, g, b);
  var I = (R + G + B)/3.0;

  H = b <= g ? H : 2*Math.PI - H;

  this.h = H*180/Math.PI,
  this.s = S*100,
  this.i = I*255;

}

ColorHSI.prototype = {

  toRGB: function() {
    var h = this.h || 0;
        s = this.s || 0;
        i = this.i || 0;

    if (120 <= h && h < 240) h = h - 120;
    if (240 <= h && h < 360) h = h - 240;

    var H = h*Math.PI/180,
        S = s/100,
        I = i/255;

    var x = I*(1 - S),
        y = I*(1 + (S*Math.cos(H)) / (Math.cos(Math.PI/3 - H))),
        z = 3*I - (x + y);

    if (0 <= h && h < 120)
      return new Color(y, z, x);
    if (120 <= h && h < 240)
      return new Color(x, y, z);
    if (240 <= h && h < 360)
      return new Color(z, x, y);
  },

  setBetween: function(beginColor, endColor, rate) {
    beginColor = new ColorHSI(beginColor);
    endColor   = new ColorHSI(endColor);

    this.h = beginColor.h + (endColor.h - beginColor.h)*rate;
    this.s = beginColor.s + (endColor.s - beginColor.s)*rate;
    this.i = beginColor.i + (endColor.i - beginColor.i)*rate;
  }

}
