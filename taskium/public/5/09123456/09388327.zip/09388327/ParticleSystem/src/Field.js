// Field.js defines the basic force field. A force field has two
// types: the attract field or the rebel field. An attract field
// draws a particle to itself while the rebel field pushes a 
// particle away from it.

function Field(configs) {

  this.position = configs.position !== undefined ? configs.position : new Vector2(0, 0);
  this.color    = configs.color    !== undefined ? configs.color    : Color.RED;
  this.size     = configs.size     !== undefined ? configs.size     : 5;
  this.type     = configs.type     !== undefined ? configs.type     : Const.ATTRACT;
  this.strength = configs.strength !== undefined ? configs.strength : 800000;
  this.movable  = false;

}

Field.prototype = {

  render: function(ctx) {

    ctx.fillStyle = "rgb("
      + Math.floor(this.color.r * 255) + ','
      + Math.floor(this.color.g * 255) + ','
      + Math.floor(this.color.b * 255) + ")";
    ctx.beginPath();
    ctx.arc(this.position.x, this.position.y, this.size, 0, Math.PI*2, true);
    ctx.closePath();
    ctx.fill();
  },

  isSelected: function(x, y) {
    if (x < this.position.x + this.size && 
        x > this.position.x - this.size)
      return y < this.position.y + this.size && 
             y > this.position.y - this.size;
    return false;
  },

  setFieldMovable: function(e) {
    var x = e.clientX - $('#particleSystem').offset().left;
    var y = e.clientY - $('#particleSystem').offset().top;

    if (this.isSelected(x, y))
      this.movable = true;
    else
      this.movable = false;
  },
  
  move: function(e) {
    var x = e.clientX - $('#particleSystem').offset().left;
    var y = e.clientY - $('#particleSystem').offset().top;

    this.position.x = x;
    this.position.y = y;
  },

}
