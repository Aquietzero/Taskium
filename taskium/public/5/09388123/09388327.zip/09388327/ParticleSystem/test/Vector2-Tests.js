var Const   = require('../Const');
var Vector2 = require('../Vector2');

// Vector2_Error_Maker takes in a error describer and then generates a string of
// error message according to the information provided by the error describer.
var Vector2_Error_Maker = function(test_args) {

  var test_type = test_args.test_type.replace(/_/, ' ') || 'unknown test type';
  var case_id   = test_args.case_id || '-1';
  var msg  = test_args.msg || 'no message';
  var args = '';

  for (var i = 0; i < test_args.args.length; ++i)
    args += test_args.args.toString() + ', ';
  
  return 'In' + test_type + 
         ', case ' + case_id + ':\n' +
         'Error message: ' + msg + '\n' +
         'With arguments: ' + args;

}


// A series of methods in class Vector2D
var Vector2_Tests = [

  function test_addition() {
    for (var i = 0; i < 100; ++i) {
      v_1 = new Vector2(Math.random(), Math.random());
      v_2 = new Vector2(Math.random(), Math.random());
      v_3 = v_1.add(v_2);

      if (v_3.x != v_1.x + v_2.x || v_3.y != v_1.y + v_2.y)
        return Vector2_Error_Maker({
          test_type : 'test_addition',
          case_id   : i,
          msg       : 'addition error',
          args      : [v_1, v_2],
        });
    }
    return Const.SUCCESS;
  },

  function test_equals() {
    for (var i = 0; i < 100; ++i) {
      v_1 = new Vector2(Math.random(), Math.random());
      v_2 = new Vector2(Math.random(), Math.random());

      if (v_1.add(v_2).equals(v_2.add(v_1)) != 0)
        return Vector2_Error_Maker({
          test_type : 'test_equals',
          case_id   : i,
          msg       : 'equals error',
          args      : [v_1, v_2],
        });
    }
    return Const.SUCCESS;

  },

  function test_subtraction() {
    return Const.SUCCESS; 
  },

]

module.exports = Vector2_Tests;
