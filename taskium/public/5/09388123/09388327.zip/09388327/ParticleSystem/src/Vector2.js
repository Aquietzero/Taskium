// Vector2.js defines a two dimensional vector.

var Vector2 = function(x, y) {
  this.x = x || 0;
  this.y = y || 0;
}

Vector2.prototype = {

  // The copy constructor of the vector.
  clone: function() {
    return new Vector2(this.x, this.y);
  },

  // The length of the vector.
  length: function() {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  },

  // The sum of the square of the x component and the y component.
  squareLength: function() {
    return this.x * this.x + this.y * this.y;
  },

  // Returns the norm of the current vector.
  normalize: function() {
    var len = this.length();
    return new Vector2(this.x / len, this.y / len);
  },

  // Normalizes the current vector and returns nothing.
  normalized: function() {
    var len = this.length();
    this.x /= len;
    this.y /= len;
  },

  // Returns the negation of the current vector.
  negate: function() {
    return new Vector2(-this.x, -this.y);
  },

  // Negates the current vector and returns nothing.
  negated: function() {
    this.x = -this.x;
    this.y = -this.y;
  },

  // Basic arithmetic operations of the vector pseudo-class.
  add: function(that) {
    return new Vector2(this.x + that.x, this.y + that.y);
  },

  sub: function(that) {
    return new Vector2(this.x - that.x, this.y - that.y);
  },

  scale: function(factor) {
    return new Vector2(this.x * factor, this.y * factor);
  },

  rotate: function(angle) {
    return new Vector2(
      this.x*Math.cos(angle) - this.y*Math.sin(angle),
      this.x*Math.sin(angle) + this.y*Math.cos(angle)
    );
  },

  // Dot product and cross product of the vector pseudo-class.
  dot: function(that) {
    return this.x * that.x + this.y + that.y;
  },

  cross: function(that) {
    return this.x * that.y - this.y * that.x;
  },

  // Some utility functions

  // If the passing vector is a valid vector, then returns
  // a value which indicates the relationship between those
  // two vectors. But if the passing object is not a vector,
  // then returns false.
  equals: function(that) {
    if (that instanceof Vector2) {
      var diff_x = this.x - that.x;
      if (diff_x == 0)
        return this.y - that.y;
      return diff_x;
    }
    return false;
  },

  // Converts a vector to a string.
  toString: function() {
    return 'Vector2(' + this.x + ', ' + this.y + ')';
  },

  // Converts a vector to a value.
  toValue: function() {
    return this.length();
  },

}


// Vector2D constants.
Vector2.ZERO = new Vector2(0, 0);
Vector2.UNIT_X = new Vector2(1, 0);
Vector2.UNIT_Y = new Vector2(0, 1);

if (typeof module != 'undefined')
  module.exports = Vector2;
