// DefaultParticleSystem.js extends from the basic particle system
// defined in ParticleSystem.js

var DefaultParticleSystem = function() {}

DefaultParticleSystem.prototype = new ParticleSystem();
DefaultParticleSystem.prototype.extendSystem({

  simulate: function(dt) {
    this._aging(dt);
    this._applyGravity();
    this._applyFields();
    this._kinematics(dt);
  },

});
