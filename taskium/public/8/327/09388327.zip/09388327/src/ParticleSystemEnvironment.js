// ParticleSystemEnvironment.js defines a simple particle system controller.
// All you need to do to get a particle system is to create it and configure
// it in the particle system environment.

function ParticleSystemEnvironment(configs) {

  // Private attributes:
  var _self = this;

  // Runtime configuration.
  var _ctx;
  var _fps;
  var _run_id;
  var _motion_blur;

  // Particle configuration.
  var _particle_config;

  // _generation_num describes the number of particles in a new
  // generation. In other words, _generation_num particles will
  // be emitted each time the emit method is called in the particle
  // system.
  var _generation_num;

  // _particle_num describes the maximum total number of particles
  // in the particle system.
  var _particle_num;

  // _particle_system refers to the current particle system.
  this.particle_system = new DefaultParticleSystem();

  // Public methods:
  this.init = function(configs) {
    configuration(configs);
  }

  this.run = function() {
    for (var i = 0; i < _generation_num; ++i) 
      _self.particle_system.emit(new Particle(_particle_config));

    _self.particle_system.simulate(_fps);

    // TODO extract it from the environment.
    if (_motion_blur) {
      _ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
      _ctx.fillRect(0, 0, 950, 550);
    }
    else {
      _ctx.fillStyle = 'black';
      _ctx.fillRect(0, 0, 950, 550);
    }

    _self.particle_system.render(_ctx);
    _run_id = setTimeout(arguments.callee, 30);
  }

  this.stop = function() {
    clearTimeout(_run_id);
  }

  // Support draggable fields.
  this.setFieldMovable = function(e) {
    _self.particle_system._setFieldMovable(e);
  }

  this.moveField = function(e) {
    _self.particle_system._moveField(e);
  }

  this.setFieldUnmovable = function() {
    _self.particle_system._setFieldUnmovable();
  }

  // Private methods:
  var configuration = function(configs) {
    _ctx = configs.ctx;
    _fps = configs.fps || 0.01;
    _particle_config = configs.particle;
    _motion_blur = configs.motion_blur;
    _generation_num = configs.generation_num || 2;

    if (configs.type) {
      switch (configs.type) {
        case Const.DEFAULT:
          break;
        case Const.RANDOM:
          _self.particle_system = new RandomParticleSystem();
          break;
      }
    }
  }
  
}
