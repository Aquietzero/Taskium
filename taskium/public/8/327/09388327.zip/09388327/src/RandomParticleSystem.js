// RandomParticleSystem.js defines another kind of particle system
// in which particles move randomly at each frame.

var RandomParticleSystem = function() {}

RandomParticleSystem.prototype = new ParticleSystem();
RandomParticleSystem.prototype.extendSystem({

  simulate: function(dt) {
    this._aging(dt);
    this._applyEffectors();
    this._kinematics(dt);
    this._applyFields();
  },

});
