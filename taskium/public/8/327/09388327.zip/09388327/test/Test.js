var Vector2_Tests = require('./Vector2-Tests');

(function Test() {
  for (var i = 0; i < Vector2_Tests.length; ++i)
    console.log(Vector2_Tests[i]());
})();
